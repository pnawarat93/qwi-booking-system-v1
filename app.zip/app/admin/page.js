"use client";

import { useEffect, useState } from "react";
import { format } from "date-fns";
import { useRouter } from "next/navigation";

import StoreInfoBar from "../components/StoreInfoBar";
import ScheduleToolbar from "../components/ScheduleToolbar";
import ScheduleGrid from "../components/ScheduleGrid";
import { useAuthStore } from "../store/useAuthStore";

export default function AdminPage() {
  const [selectedDate, setSelectedDate] = useState(
    new Date().toISOString().split("T")[0]
  );

  const { user } = useAuthStore();
  const router = useRouter();

  useEffect(() => {
    if (!user) {
      router.push("/login");
    }
  }, [user, router]);

  return (
    <main className="flex h-full flex-col">
      <div className="shrink-0 border-b bg-white">
        <StoreInfoBar
          shopName="Wellness Thai Massage"
          shopPhone="02 1234 5678"
          shopAddress="123 Pitt Street, Sydney"
        />
      </div>

      <div className="shrink-0 border-b bg-white">
        <ScheduleToolbar
          selectedDate={selectedDate}
          onDateChange={(e) => setSelectedDate(e.target.value)}
          dateLabel={format(new Date(selectedDate), "EEEE, d MMMM yyyy")}
        />
      </div>

      <section className="min-h-0 flex-1 overflow-hidden">
        <div className="h-full overflow-auto">
          <ScheduleGrid selectedDate={selectedDate} />
        </div>
      </section>
    </main>
  );
}